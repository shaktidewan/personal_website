{/* <div class="navbar-line"> */}
const hamburger = document.querySelector(".navbar-line");

{/* <ul class="nav-links"> */}
const navLinks = document.querySelector(".nav-links");
const links = document.querySelectorAll(".nav-links li");

//if user click it 
hamburger.addEventListener("click", () => {
  navLinks.classList.toggle("open"); //open the nav bar
  links.forEach(link => {
    link.classList.toggle("fade");
  });
});
